#include "Analisador.hpp"

int Analisador::calcula_ultimo_valor(Funcao *f, const vector<int> &params) {
  map<string, int*> T;
  T[string("a")] = (int*) malloc(sizeof(int));

  (*(T[string("a")])) = 10;
  // Preencher aqui.
  return 0;
}
