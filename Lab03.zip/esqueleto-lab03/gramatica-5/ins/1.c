int f(){
int a;
a=a+a*a+10;
}
