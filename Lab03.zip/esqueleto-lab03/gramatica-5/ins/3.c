double funcao(int a, double b, char c) {
  int aa;
  double bb;
  int cc;
  int dd;
  cc = 10;
  dd = 44;
  {
    int cc;
    cc = 2;
    dd = dd * cc;
  }
  aa = dd + cc;
}
